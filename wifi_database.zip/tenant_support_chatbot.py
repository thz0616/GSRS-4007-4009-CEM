import customtkinter as ctk
import datetime
import requests
import json
import threading
from PIL import Image, ImageTk
import os
import sqlite3
import tkinter.messagebox as messagebox

# Define color constants
SIDEBAR_COLOR = "#E8DCD0"  # Light beige for sidebar
MAIN_BG_COLOR = "#F2EAE4"  # Lighter beige for main background
USER_MSG_COLOR = "#E8DCD0"  # Light beige for user messages
BOT_MSG_COLOR = "#F2EAE4"  # Lighter beige for bot messages
TEXT_COLOR = "#6B4423"     # Brown for text
ACCENT_COLOR = "#8B4513"   # Saddle brown for buttons
INPUT_BG_COLOR = "#FFFFFF" # White for input background

class TenantSupportChatbot:
    def __init__(self, parent_window=None, dashboard=None):
        # API Configuration
        self.API_BASE_URL = "https://api.dify.ai/v1"
        self.API_KEY = self.get_api_key_from_db()
        self.conversation_id = None
        self.dashboard = dashboard
        
        if not self.API_KEY:
            messagebox.showerror("Error", "No API key available. Chat functionality will be limited.")
            return
        
        # Use parent_window if provided, otherwise create new window
        if parent_window:
            self.window = parent_window
        else:
            self.window = ctk.CTk()
            self.window.title("Government Stall Rental Support")
            self.window.geometry("2000x1200")
        
        self.window.configure(fg_color=MAIN_BG_COLOR)

        # Create main container with sidebar and chat area
        self.create_layout()
        
        # Initialize conversation with system message
        self.add_message("assistant", """Hello! I'm your Government Stall Rental System assistant. I can help you with:

1. Check-in procedures and requirements
2. Understanding your rental status
3. Using the face verification system
4. Navigating the rental management system
5. Understanding rental policies and regulations

What would you like to know about?""")

        # Only run mainloop if we created our own window
        if not parent_window:
            self.window.mainloop()

    def get_api_key_from_db(self):
        try:
            conn = sqlite3.connect('properties.db')
            cursor = conn.cursor()
            cursor.execute("SELECT api_key FROM systemInformation ORDER BY created_at DESC LIMIT 1")
            result = cursor.fetchone()
            if result and result[0]:
                return result[0]
            else:
                messagebox.showerror("Error", "No API key found in database. Please contact system administrator.")
                return None
        except sqlite3.Error as e:
            messagebox.showerror("Database Error", f"Error accessing database: {e}")
            return None
        finally:
            if conn:
                conn.close()

    def create_layout(self):
        # Create sidebar
        self.sidebar = ctk.CTkFrame(
            self.window,
            fg_color=SIDEBAR_COLOR,
            width=400
        )
        self.sidebar.pack(side="left", fill="y", padx=0, pady=0)
        self.sidebar.pack_propagate(False)

        # Back button
        back_btn = ctk.CTkButton(
            self.sidebar,
            text="← Back",
            command=self.go_back,
            fg_color=ACCENT_COLOR,
            hover_color="#6B4423",
            height=50,
            width=340,
            font=("Arial Bold", 24),
            text_color="#FFFFFF"
        )
        back_btn.pack(pady=(30, 15), padx=30)

        # New Chat button
        new_chat_btn = ctk.CTkButton(
            self.sidebar,
            text="+ New Chat",
            command=self.new_chat,
            fg_color=ACCENT_COLOR,
            hover_color="#6B4423",
            height=60,
            width=340,
            font=("Arial Bold", 24),
            text_color="#FFFFFF"
        )
        new_chat_btn.pack(pady=(15, 30), padx=30)

        # Add a separator
        separator = ctk.CTkFrame(self.sidebar, height=2, fg_color="#404040")
        separator.pack(fill="x", padx=20, pady=10)

        # Quick access buttons for common topics
        topics = [
            ("Check-in Guide", "🔑"),
            ("Face Verification Help", "👤"),
            ("Rental Status", "📊"),
            ("System Navigation", "🧭"),
            ("Policies & Rules", "📋")
        ]
        
        for topic, icon in topics:
            btn = ctk.CTkButton(
                self.sidebar,
                text=f"{icon}  {topic}",
                command=lambda t=topic: self.quick_access_topic(t),
                fg_color="transparent",
                hover_color="#D4C3B3",
                height=55,
                width=340,
                anchor="w",
                font=("Arial", 22),
                text_color=TEXT_COLOR
            )
            btn.pack(pady=8, padx=30)

        # Create main chat area
        self.main_area = ctk.CTkFrame(
            self.window,
            fg_color=MAIN_BG_COLOR
        )
        self.main_area.pack(side="right", fill="both", expand=True)

        # Create chat display area
        self.chat_frame = ctk.CTkScrollableFrame(
            self.main_area,
            fg_color=MAIN_BG_COLOR
        )
        self.chat_frame.pack(fill="both", expand=True, padx=40, pady=20)

        # Create input area
        self.input_frame = ctk.CTkFrame(
            self.main_area,
            fg_color=MAIN_BG_COLOR,
            height=150
        )
        self.input_frame.pack(fill="x", side="bottom", padx=50, pady=40)
        self.input_frame.pack_propagate(False)

        # Create text input
        self.message_input = ctk.CTkTextbox(
            self.input_frame,
            height=90,
            fg_color=INPUT_BG_COLOR,
            text_color=TEXT_COLOR,
            wrap="word",
            font=("Arial", 24),
            border_width=1,
            border_color="#D4C3B3"
        )
        self.message_input.pack(fill="x", padx=(0, 90), pady=30)

        # Create send button with emoji
        self.send_button = ctk.CTkButton(
            self.input_frame,
            text="➤",
            width=70,
            height=70,
            command=self.send_message,
            fg_color=ACCENT_COLOR,
            hover_color="#6B4423",
            font=("Arial", 36),
            text_color="#FFFFFF"
        )
        self.send_button.place(relx=0.97, rely=0.5, anchor="center")

        # Bind Enter key to send message
        self.message_input.bind("<Return>", self.send_message)
        self.message_input.bind("<Shift-Return>", lambda e: "break")

    def new_chat(self):
        # Clear chat history
        for widget in self.chat_frame.winfo_children():
            widget.destroy()
        
        # Reset conversation ID
        self.conversation_id = None
        
        # Add initial message
        self.add_message("assistant", """Hello! I'm your Government Stall Rental System assistant. I can help you with:

1. Check-in procedures and requirements
2. Understanding your rental status
3. Using the face verification system
4. Navigating the rental management system
5. Understanding rental policies and regulations

What would you like to know about?""")

    def quick_access_topic(self, topic):
        topic_prompts = {
            "Check-in Guide": "Please explain the daily check-in process step by step.",
            "Face Verification Help": "How does the face verification system work and what should I do if it fails?",
            "Rental Status": "How can I check my current rental status and payment information?",
            "System Navigation": "Please explain how to navigate the main features of the rental system.",
            "Policies & Rules": "What are the key policies and rules I need to follow as a tenant?"
        }
        
        self.message_input.delete("1.0", "end")
        self.message_input.insert("1.0", topic_prompts[topic])
        self.send_message()

    def send_message(self, event=None):
        message = self.message_input.get("1.0", "end-1c").strip()
        if message:
            # Clear input
            self.message_input.delete("1.0", "end")
            
            # Add user message to chat
            self.add_message("user", message)
            
            # Disable input while processing
            self.message_input.configure(state="disabled")
            self.send_button.configure(state="disabled")
            
            # First check if the question is relevant
            if not self.is_question_relevant(message):
                # Add bot response for irrelevant question
                self.add_message("assistant", """I can only assist with questions related to the Government Stall Rental System. Please ask about:

• Check-in procedures
• Face verification system
• Rental status
• System navigation
• Rental policies and rules

How can I help you with any of these topics?""")
                
                # Re-enable input
                self.enable_input()
                return

            # Start API request in a separate thread for relevant questions
            threading.Thread(target=self.send_api_request, args=(message,), daemon=True).start()

        if event:
            return "break"

    def is_question_relevant(self, message):
        headers = {
            "Authorization": f"Bearer {self.API_KEY}",
            "Content-Type": "application/json"
        }
        
        relevance_check_prompt = """You are a filter for a Government Stall Rental System chatbot.
Your task is to determine if the user's question is related to:
1. Daily check-in procedures
2. Face verification system
3. Rental status
4. System navigation
5. Rental policies and rules
6. Any other aspects of the Government Stall Rental System

User Question: """ + message + """

Respond with only 'YES' if the question is related to the system, or 'NO' if it's unrelated.
For example:
- "How do I check in?" -> YES
- "What's the weather today?" -> NO
- "Why did my face verification fail?" -> YES
- "Can you recommend a restaurant?" -> NO"""

        try:
            response = requests.post(
                f"{self.API_BASE_URL}/chat-messages",
                headers=headers,
                json={
                    "inputs": {},
                    "query": relevance_check_prompt,
                    "user": "system",
                    "response_mode": "blocking"  # Use blocking mode for immediate response
                }
            )
            
            if response.status_code == 200:
                answer = response.json().get('answer', '').strip().upper()
                return answer == 'YES'
            
            return True  # Default to True if API call fails
            
        except Exception as e:
            print(f"Error checking question relevance: {str(e)}")
            return True  # Default to True if there's an error

    def send_api_request(self, message):
        headers = {
            "Authorization": f"Bearer {self.API_KEY}",
            "Content-Type": "application/json"
        }
        
        # Define system knowledge
        system_knowledge = """You are a helpful assistant for tenants using the Government Stall Rental System. Always respond in a friendly and helpful manner, as if you're having a conversation with the tenant. Avoid referring to "the system knowledge" or "the provided text" in your responses.

Here's what you know about the system:

Daily Check-in System:
- Tenants need to perform one check-in per day at their rental property
- For check-in, you need:
  • A device with a working camera
  • Internet connection
  • Location services enabled
- The system verifies:
  • Your identity through face verification
  • Your location at the rental property
- You'll get one of these status messages:
  • "Check-in Successfully" - All verifications passed
  • "Partially Check-in (Camera verification passed)" - Only face verified
  • "Partially Check-in (Location verification passed)" - Only location verified
  • "Check-in Failed" - No verifications failed

Payment System:
- Payment Rules:
  • First Month: You must pay the full amount even if starting mid-month
  • Last Month: You don't need to pay for your final partial month to avoid overlap
  • Regular months: Pay your full monthly rental amount
- Payment Options:
  • Credit/Debit Card: Make direct payments with immediate confirmation
  • Online Banking: Transfer to our bank account and upload your receipt
  • Touch 'n Go: Pay with your eWallet and upload your receipt

Feedback System:
- Types of Feedback:
  • Complaints: Report issues with your rental property
  • System Issues: Report technical problems with the rental system
  • Payment Issues: Report problems with payment processing
  • Feature Requests: Suggest improvements or new features
- How to Submit:
  • Choose a feedback category
  • Provide a clear subject
  • Write detailed comments about your concern
  • Submit using the SEND button

User Question: """ + message + """

Please provide a friendly, helpful response that directly addresses the tenant's question. Keep your response within 100 words, be concise but thorough, and maintain a conversational tone."""
        
        data = {
            "inputs": {},
            "query": system_knowledge,
            "user": "tenant",
            "response_mode": "streaming",
            "conversation_id": self.conversation_id if self.conversation_id else None
        }

        try:
            response = requests.post(
                f"{self.API_BASE_URL}/chat-messages",
                headers=headers,
                json=data,
                stream=True
            )
            
            if response.status_code != 200:
                self.window.after(0, self.add_message, "assistant", 
                                f"Sorry, I encountered an error. Please try again later.")
                return

            # Create initial empty message
            self.window.after(0, self.add_message, "assistant", "")
            accumulated_answer = ""

            for line in response.iter_lines():
                if line:
                    try:
                        json_str = line.decode('utf-8').replace('data: ', '')
                        data = json.loads(json_str)
                        
                        if data.get("event") == "message":
                            # Get new text chunk
                            new_text = data.get("answer", "")
                            accumulated_answer += new_text
                            # Update the last message with accumulated text
                            self.window.after(0, self.update_last_message, accumulated_answer)
                        elif data.get("event") == "message_end":
                            self.conversation_id = data.get("conversation_id")
                            break
                    except json.JSONDecodeError:
                        continue

        except Exception as e:
            self.window.after(0, self.add_message, "assistant", 
                            f"Sorry, I encountered an error: {str(e)}")
        finally:
            self.window.after(0, self.enable_input)

    def update_last_message(self, new_text):
        """Update the last message in the chat frame"""
        if self.chat_frame.winfo_children():
            last_message = self.chat_frame.winfo_children()[-1]
            content_frame = last_message.winfo_children()[0]
            
            # Remove existing message label
            for widget in content_frame.winfo_children():
                widget.destroy()
            
            # Add bot emoji
            sender_label = ctk.CTkLabel(
                content_frame,
                text="🤖",
                font=("Arial", 28)
            )
            sender_label.pack(anchor="w", pady=(0, 10))
            
            # Add updated message with larger font
            message_label = ctk.CTkLabel(
                content_frame,
                text=self._convert_markdown(new_text),
                wraplength=800,
                justify="left",
                text_color=TEXT_COLOR,
                font=("Arial", 24)
            )
            message_label.pack(anchor="w")

    def add_message(self, sender, message):
        # Create message frame
        bg_color = USER_MSG_COLOR if sender == "user" else BOT_MSG_COLOR
        message_frame = ctk.CTkFrame(
            self.chat_frame,
            fg_color=bg_color,
            corner_radius=10
        )
        message_frame.pack(fill="x", pady=10)

        # Create message content frame
        content_frame = ctk.CTkFrame(
            message_frame,
            fg_color=bg_color
        )
        content_frame.pack(fill="x", padx=300, pady=25)

        # Add sender icon/label
        icon = "👤" if sender == "user" else "🤖"
        sender_label = ctk.CTkLabel(
            content_frame,
            text=icon,
            font=("Arial", 28)
        )
        sender_label.pack(anchor="w", pady=(0, 10))

        # Handle markdown formatting
        formatted_message = self._convert_markdown(message)

        # Add message text with proper formatting
        if "```" in message:  # Code block
            # Create a textbox for code blocks
            message_box = ctk.CTkTextbox(
                content_frame,
                height=120,
                wrap="none",
                font=("Courier", 20),
                text_color=TEXT_COLOR,
                fg_color="#F5F5F5"
            )
            message_box.pack(fill="x", pady=5)
            message_box.insert("1.0", formatted_message)
            message_box.configure(state="disabled")
        else:
            # Regular text with markdown formatting
            message_label = ctk.CTkLabel(
                content_frame,
                text=formatted_message,
                wraplength=800,
                justify="left",
                text_color=TEXT_COLOR,
                font=("Arial", 24)
            )
            message_label.pack(anchor="w")

        # Auto-scroll to the bottom
        self.chat_frame._parent_canvas.yview_moveto(1.0)

    def _convert_markdown(self, text):
        """Convert markdown to formatted text"""
        # Handle code blocks
        if "```" in text:
            # Extract code between backticks
            parts = text.split("```")
            result = []
            for i, part in enumerate(parts):
                if i % 2 == 0:  # Outside code block
                    result.append(self._format_regular_text(part))
                else:  # Inside code block
                    result.append(part.strip())
            return "\n".join(result)
        else:
            return self._format_regular_text(text)

    def _format_regular_text(self, text):
        """Format regular text with markdown"""
        lines = []
        for line in text.split('\n'):
            # Headers
            if line.startswith('# '):
                line = f"\n{line[2:].upper()}\n"
            elif line.startswith('## '):
                line = f"\n{line[3:].title()}\n"
            
            # Bold
            while '**' in line:
                line = line.replace('**', '', 2)
            
            # Lists
            if line.strip().startswith('- '):
                line = '  • ' + line[2:]
            elif line.strip().startswith('* '):
                line = '  • ' + line[2:]
            
            # Numbered lists
            if line.strip() and line[0].isdigit() and line[1:].startswith('. '):
                line = f"  {line[0]}) {line[3:]}"
            
            lines.append(line)
        
        return '\n'.join(lines)

    def enable_input(self):
        """Re-enable input controls"""
        self.message_input.configure(state="normal")
        self.send_button.configure(state="normal")
        self.message_input.focus()

    def go_back(self):
        # Find the toplevel window
        parent = self.window
        while not isinstance(parent, ctk.CTkToplevel) and parent.master is not None:
            parent = parent.master
        
        if isinstance(parent, ctk.CTkToplevel):
            parent.destroy()  # Close the chat window
            
        # Show dashboard window if available
        if self.dashboard and hasattr(self.dashboard, 'master'):
            self.dashboard.master.deiconify()

if __name__ == "__main__":
    app = TenantSupportChatbot() 